'use strict';
// Uji klien api.obfuscate.club dengan fetch palsu. Tanpa jaringan, tanpa key asli.
const { obfuscateWithObfClub, ENDPOINT } = require('../obfuscate-club-api');

let ok = 0, fail = 0;
const check = (name, cond, extra = '') => { console.log(`${cond ? 'OK  ' : 'FAIL'} ${name}${cond || !extra ? '' : ` [${extra}]`}`); cond ? ok++ : fail++; };

function fakeFetch(res) {
  const calls = [];
  const fn = async (url, init) => {
    calls.push({ url, init });
    return {
      ok: res.status === undefined || (res.status >= 200 && res.status < 300),
      status: res.status ?? 200,
      json: async () => { if (res.bad) throw new SyntaxError('bukan json'); return res.body; },
    };
  };
  return { fn, calls };
}

(async () => {
  // sukses: request sesuai curl (URL, Bearer, body source+target), hasil dari field code
  {
    const f = fakeFetch({ body: { code: 'local _=string.char(112)' } });
    const out = await obfuscateWithObfClub(Buffer.from('print(1)'), { apiKey: 'obf_KEY', fetchImpl: f.fn });
    check('sukses: hasil dari field code', out.toString() === 'local _=string.char(112)');
    check('request: URL endpoint sama seperti curl', f.calls[0].url === 'https://api.obfuscate.club/v1/obfuscate' && ENDPOINT === f.calls[0].url);
    check('request: POST dengan Bearer dan Content-Type json', f.calls[0].init.method === 'POST' && f.calls[0].init.headers.Authorization === 'Bearer obf_KEY' && f.calls[0].init.headers['Content-Type'] === 'application/json');
    check('request: body {source, target} default lua54', f.calls[0].init.body === JSON.stringify({ source: 'print(1)', target: 'lua54' }));
  }

  // target bisa diganti
  {
    const f = fakeFetch({ body: { code: 'X=1 --' } });
    await obfuscateWithObfClub(Buffer.from('print(1)'), { apiKey: 'K', target: 'luau', fetchImpl: f.fn });
    check('target custom dikirim', JSON.parse(f.calls[0].init.body).target === 'luau');
  }

  // field hasil lain (output) juga diterima
  {
    const f = fakeFetch({ body: { output: 'OUT_CODE' } });
    const out = await obfuscateWithObfClub(Buffer.from('print(1)'), { apiKey: 'K', fetchImpl: f.fn });
    check('field output diterima', out.toString() === 'OUT_CODE');
  }

  // HTTP 401: pesan error dari server ikut
  {
    let msg = '';
    try { await obfuscateWithObfClub(Buffer.from('x'), { apiKey: 'K', fetchImpl: fakeFetch({ status: 401, body: { error: { message: 'key tidak valid' } } }).fn }); } catch (e) { msg = e.message; }
    check('401: status dan pesan server ikut', msg.includes('401') && msg.includes('key tidak valid'), msg);
  }

  // respons bukan JSON
  {
    let msg = '';
    try { await obfuscateWithObfClub(Buffer.from('x'), { apiKey: 'K', fetchImpl: fakeFetch({ bad: true }).fn }); } catch (e) { msg = e.message; }
    check('bukan JSON: pesan jelas', msg.includes('bukan JSON'), msg);
  }

  // tanpa field hasil
  {
    let msg = '';
    try { await obfuscateWithObfClub(Buffer.from('x'), { apiKey: 'K', fetchImpl: fakeFetch({ body: { ok: true } }).fn }); } catch (e) { msg = e.message; }
    check('tanpa field hasil: ditolak', msg.includes('tidak berisi kode'), msg);
  }

  // hasil sama dengan source (beda komentar/spasi saja): ditolak
  {
    let msg = '';
    try { await obfuscateWithObfClub(Buffer.from('local a = 1\nprint(a)'), { apiKey: 'K', fetchImpl: fakeFetch({ body: { code: '--[[ hdr ]]\nlocal   a = 1\n\nprint(a)' } }).fn }); } catch (e) { msg = e.message; }
    check('hasil tanpa perubahan: ditolak', msg.includes('tanpa perubahan'), msg);
  }

  // tanpa key dan source kosong: ditolak sebelum request
  {
    let msg = '';
    try { await obfuscateWithObfClub(Buffer.from('x'), { apiKey: '', fetchImpl: fakeFetch({ body: {} }).fn }); } catch (e) { msg = e.message; }
    check('tanpa key: ditolak', msg.includes('OBF_API_KEY'));
    msg = '';
    try { await obfuscateWithObfClub(Buffer.alloc(0), { apiKey: 'K', fetchImpl: fakeFetch({ body: {} }).fn }); } catch (e) { msg = e.message; }
    check('source kosong: ditolak', msg === 'source kosong');
  }

  // banner: blok komentar Lua dengan ASCII art, kode asli utuh di bawahnya
  {
    const { addLuaBanner } = require('../obfuscate-club-api');
    const code = Buffer.from('local _=1\nprint(_)');
    const out = addLuaBanner(code, 'ALLZXRAA COMMUNITY').toString('utf8');
    check('banner: diawali blok komentar --[[', out.startsWith('--[[\n'));
    check('banner: ASCII art ada di dalam blok', out.includes('█████╗') && out.includes('Script ini diproteksi'));
    check('banner: blok ditutup ]] lalu kode asli utuh', out.endsWith('\n]]\nlocal _=1\nprint(_)'));
    check('banner: brand dimasukkan ke baris teks', out.includes('Obfu Lua by ALLZXRAA COMMUNITY'));
    const brandOut = addLuaBanner(code, 'MY]]BRAND').toString('utf8');
    check('banner: brand dengan ]] tidak menutup komentar lebih awal', brandOut.split(']]').length === 2);
    check('banner: brand kosong pakai nama default', addLuaBanner(code, '  ').toString('utf8').includes('Obfu Lua by ALLZXRAA COMMUNITY'));
  }

  console.log({ ok, fail });
  process.exit(fail ? 1 : 0);
})();

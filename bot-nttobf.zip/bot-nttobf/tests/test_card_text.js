'use strict';
// Uji logika teks kartu tanpa canvas: wrapLines/breakWord (cards.js) dan pickTexts (info_cards.js).
// measureText dipalsukan: 10 px per karakter.
const cards = require('../cards');
const info = require('../info_cards');

let ok = 0, fail = 0;
const check = (name, cond, extra = '') => { console.log(`${cond ? 'OK  ' : 'FAIL'} ${name}${cond || !extra ? '' : ` [${extra}]`}`); cond ? ok++ : fail++; };
const fakeCtx = { measureText: (s) => ({ width: String(s).length * 10 }) };

// 1. teks panjang: semua kata tetap ada, tidak ada "…" (tidak dipotong)
{
  const text = Array.from({ length: 60 }, (_, i) => `kata${i}`).join(' ');
  const lines = cards.wrapLines(fakeCtx, text, 200);
  check('wrap: teks panjang tanpa batas baris tidak dipotong', lines.join(' ') === text && !lines.join('').includes('…'), `${lines.length} baris`);
  check('wrap: tiap baris muat lebarnya', lines.every((l) => fakeCtx.measureText(l).width <= 200));
}

// 2. kata lebih lebar dari kartu (URL/token): dipecah per karakter, tidak ada karakter hilang
{
  const url = 'https://example.com/' + 'a'.repeat(120);
  const lines = cards.wrapLines(fakeCtx, `lihat ${url} ya`, 300);
  check('wrap: URL panjang tidak kehilangan karakter', lines.join('').replace(/\s/g, '').includes(url));
  check('wrap: URL panjang dipecah jadi beberapa baris', lines.length > 3 && !lines.join('').includes('…'), `${lines.length} baris`);
  check('breakWord: tiap potongan muat', cards.breakWord(fakeCtx, 'x'.repeat(95), 200).every((p) => fakeCtx.measureText(p).width <= 200));
}

// 3. dengan batas baris (perilaku lama tetap ada kalau diminta)
{
  const text = Array.from({ length: 60 }, (_, i) => `kata${i}`).join(' ');
  const lines = cards.wrapLines(fakeCtx, text, 200, 3);
  check('wrap: dengan maxLines=3 dibatasi 3 baris dan diberi "…"', lines.length === 3 && lines[2].endsWith('…'));
}

// 4. pickTexts: deskripsi multi-baris tidak lagi hilang setelah baris pertama
{
  const payload = { embeds: [{ data: { title: 'Judul', description: 'baris pertama\nbaris kedua penting\nbaris ketiga' } }] };
  const t = info.pickTexts(payload);
  check('pickTexts: deskripsi multi-baris utuh', t.subtitle.includes('baris kedua penting') && t.subtitle.includes('baris ketiga'), t.subtitle);
}

// 5. pickTexts: teks panjang sampai batas dipotong dengan "…", di bawah batas utuh
{
  const long = 'a '.repeat(600).trim();
  const t = info.pickTexts({ embeds: [{ data: { title: 'T', description: long } }] });
  check('pickTexts: di atas batas diberi "…" dan tidak lebih dari 900', t.subtitle.endsWith('…') && t.subtitle.length <= 900, `${t.subtitle.length}`);
  const short = 'a '.repeat(200).trim();
  const t2 = info.pickTexts({ embeds: [{ data: { title: 'T', description: short } }] });
  check('pickTexts: di bawah batas utuh tanpa "…"', t2.subtitle === short.replace(/ +/g, ' ') && !t2.subtitle.endsWith('…'));
}

// 6. keepEmbed: payload panel dikirim apa adanya (embed tetap, tanpa gambar kartu)
(async () => {
  const panel = { embeds: [{ data: { title: 'Panel' } }], components: [{ type: 1 }], keepEmbed: true };
  const out = await info.addCard(panel, { cards: { renderInfoCard: async () => { throw new Error('tidak boleh dipanggil'); } }, discord: {} });
  check('keepEmbed: embed dan komponen tetap, tanpa files', out.embeds === panel.embeds && out.components === panel.components && out.keepEmbed === undefined && !out.files);
  console.log({ ok, fail });
  process.exit(fail ? 1 : 0);
})();

'use strict';
const { parseEnv, loadEnvFile } = require('../env-file');
let ok = 0, fail = 0;
const check = (name, cond) => { console.log(`${cond ? 'OK  ' : 'FAIL'} ${name}`); cond ? ok++ : fail++; };

{
  const v = parseEnv('# komentar\n\nBOT_ROLE=level\nTOKEN_LEVEL="abc.def"\nLUAOBF_API_KEY=\'obf_x\'\n  SPASI = nilai  \nbukan baris valid\n1BAD=x\n');
  check('baca KEY=VALUE', v.BOT_ROLE === 'level');
  check('buang tanda kutip ganda dan tunggal', v.TOKEN_LEVEL === 'abc.def' && v.LUAOBF_API_KEY === 'obf_x');
  check('trim spasi di key dan value', v.SPASI === 'nilai');
  check('abaikan komentar, baris rusak, dan key tidak valid', Object.keys(v).length === 4);
}
{
  const env = { BOT_ROLE: 'welcome' };
  const n = loadEnvFile('/x/.env', env, () => 'BOT_ROLE=level\nTOKEN_LEVEL=t1\n', () => true);
  check('env yang sudah ada tidak ditimpa', env.BOT_ROLE === 'welcome');
  check('key baru dimuat dari file', env.TOKEN_LEVEL === 't1' && n === 1);
}
{
  const env = {};
  check('file tidak ada: tidak error', loadEnvFile('/x/none', env, () => '', () => false) === 0);
}
console.log({ ok, fail });
process.exit(fail ? 1 : 0);

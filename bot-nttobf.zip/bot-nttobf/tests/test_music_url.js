'use strict';
// Uji /voice play (link) dan /voice skip di music.js. Tanpa jaringan: openUrl dan voice lib di-stub.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const m = require('../music');

let ok = 0, fail = 0;
const check = (name, cond) => { console.log(`${cond ? 'OK  ' : 'FAIL'} ${name}`); cond ? ok++ : fail++; };
const tick = () => new Promise((r) => setImmediate(r));

const fakeVoice = () => {
  const players = [];
  const lib = {
    AudioPlayerStatus: { Idle: 'idle', Playing: 'playing' },
    NoSubscriberBehavior: { Pause: 'pause' },
    played: [],
    createAudioResource: (input, opts) => ({ input, volume: { v: null, setVolume(x) { this.v = x; } } }),
    createAudioPlayer: () => {
      const p = new EventEmitter();
      p.play = (r) => { lib.played.push(r); };
      p.stop = () => { p.stopped = true; p.emit('idle'); }; // seperti library: stop -> Idle
      players.push(p);
      return p;
    },
  };
  return { lib, players };
};
const fakeConn = () => ({ subscribe() { return { unsubscribe() {} }; } });
const quietLog = { warns: [], warn(x) { this.warns.push(x); } };

const makeStream = (name) => ({ name, destroyed: false, destroy() { this.destroyed = true; } });

const dirWith = (names) => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'music-url-'));
  for (const n of names) fs.writeFileSync(path.join(d, n), '');
  return d;
};

(async () => {
  // judul link
  check('urlTitle: nama file tanpa ekstensi, underscore jadi spasi', m.urlTitle('https://x.test/a/lagu_indo.mp3') === 'lagu indo');
  check('urlTitle: path kosong pakai host', m.urlTitle('https://radio.test/') === 'radio.test');
  check('urlTitle: url rusak dikembalikan apa adanya', m.urlTitle('bukan url') === 'bukan url');

  // tanpa openUrl: fitur link nonaktif
  {
    const { lib } = fakeVoice();
    const mu = m.createMusic({ voiceLib: lib, dir: dirWith([]), log: quietLog });
    mu.start('G0', fakeConn());
    check('tanpa openUrl: enqueueUrl ditolak', mu.enqueueUrl('G0', 'https://a.test/x.mp3').ok === false);
    mu.stop('G0');
  }

  // tanpa sesi voice
  {
    const { lib } = fakeVoice();
    const mu = m.createMusic({ voiceLib: lib, dir: dirWith([]), openUrl: async () => makeStream('s'), log: quietLog });
    const r = mu.enqueueUrl('TIDAK_ADA', 'https://a.test/x.mp3');
    check('tanpa sesi: ditolak dengan alasan jelas', r.ok === false && r.reason.includes('belum stay'));
  }

  // folder kosong, bot diam: link langsung diputar
  {
    const { lib } = fakeVoice();
    const opened = [];
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith([]), log: quietLog,
      openUrl: async (u) => { opened.push(u); return makeStream(u); },
    });
    mu.start('G1', fakeConn());
    const r = mu.enqueueUrl('G1', 'https://a.test/lagu_satu.mp3');
    await tick();
    check('bot diam: link langsung dibuka dan diputar', r.ok && r.playingNow === false && opened.length === 1 && lib.played.length === 1);
    check('nowPlaying: judul dari link', mu.nowPlaying('G1') === 'lagu satu');
    mu.stop('G1');
  }

  // sedang memutar lagu folder: link menunggu, diputar setelah lagu selesai
  {
    const { lib, players } = fakeVoice();
    const opened = [];
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith(['a.mp3']), log: quietLog,
      openUrl: async (u) => { opened.push(u); return makeStream(u); },
    });
    mu.start('G2', fakeConn());
    const r = mu.enqueueUrl('G2', 'https://a.test/b.ogg');
    check('sedang memutar: link masuk antrean, belum dibuka', r.ok && r.playingNow === true && r.position === 1 && opened.length === 0);
    players[0].emit('idle');
    await tick();
    check('lagu folder selesai: link dibuka dan diputar', opened.length === 1 && lib.played.length === 2 && lib.played[1].input.name === 'https://a.test/b.ogg');
    mu.stop('G2');
  }

  // stream ditutup saat lagu link selesai
  {
    const { lib, players } = fakeVoice();
    const streams = [];
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith([]), log: quietLog,
      openUrl: async (u) => { const s = makeStream(u); streams.push(s); return s; },
    });
    mu.start('G3', fakeConn());
    mu.enqueueUrl('G3', 'https://a.test/c.mp3');
    await tick();
    players[0].emit('idle');
    check('stream link ditutup setelah selesai', streams.length === 1 && streams[0].destroyed === true);
    mu.stop('G3');
  }

  // buka link gagal: dicatat, lalu lanjut ke lagu folder
  {
    const { lib, players } = fakeVoice();
    const log = { warns: [], warn(x) { this.warns.push(x); } };
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith(['ok.mp3']), log,
      openUrl: async () => { throw new Error('halaman web'); },
    });
    mu.start('G4', fakeConn());
    mu.enqueueUrl('G4', 'https://a.test/halaman');
    players[0].emit('idle'); // lagu folder selesai -> link dicoba
    for (let i = 0; i < 5; i++) await tick();
    check('link gagal: dicatat dan bot lanjut putar lagu folder', log.warns.some((w) => w.includes('halaman web')) && lib.played.length === 2 && lib.played[1].input.endsWith('ok.mp3'));
    mu.stop('G4');
  }

  // skip: Idle dari library memutar lagu berikutnya (link)
  {
    const { lib, players } = fakeVoice();
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith(['a.mp3']), log: quietLog,
      openUrl: async (u) => makeStream(u),
    });
    mu.start('G5', fakeConn());
    mu.enqueueUrl('G5', 'https://a.test/next.mp3');
    const did = mu.skip('G5');
    await tick();
    check('skip: lagu berhenti dan link berikutnya diputar', did === true && players[0].stopped === true && lib.played.some((r) => r.input.name === 'https://a.test/next.mp3'));
    check('skip: tanpa sesi = false', mu.skip('NOPE') === false);
    mu.stop('G5');
  }

  // cap antrean
  {
    const { lib } = fakeVoice();
    const mu = m.createMusic({
      voiceLib: lib, dir: dirWith(['a.mp3']), log: quietLog,
      openUrl: () => new Promise(() => {}), // selalu membuka, tidak pernah selesai
    });
    mu.start('G6', fakeConn());
    let last = null;
    for (let i = 0; i < m.MAX_PENDING_URLS + 3; i++) last = mu.enqueueUrl('G6', `https://a.test/${i}.mp3`);
    check('antrean penuh: ditolak setelah batas', last.ok === false && last.reason.includes('penuh'));
    mu.stop('G6');
  }

  console.log({ ok, fail });
  process.exit(fail ? 1 : 0);
})();

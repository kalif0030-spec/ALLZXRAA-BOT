'use strict';
// Uji backend api.nttobf.com dengan fetch palsu. Tanpa jaringan.
const { obfuscateWithNtt, getNttQueue, ENDPOINT, QUEUE_ENDPOINT, PAYLOAD_KEY } = require('../nttobf-api');

let ok = 0, fail = 0;
const check = (name, cond, extra = '') => { console.log(`${cond ? 'OK  ' : 'FAIL'} ${name}${cond || !extra ? '' : ` [${extra}]`}`); cond ? ok++ : fail++; };

function fakeFetch(r) {
  const calls = [];
  const fn = async (url, init) => {
    calls.push({ url, init });
    return {
      ok: r.status === undefined || (r.status >= 200 && r.status < 300),
      status: r.status ?? 200,
      json: async () => { if (r.bad) throw new SyntaxError('bukan json'); return r.body; },
    };
  };
  return { fn, calls };
}

(async () => {
  check('endpoint sama dengan snippet user', ENDPOINT === 'https://api.nttobf.com/obfuscate');

  // sukses
  {
    const f = fakeFetch({ body: { result: 'OBF()' } });
    const out = await obfuscateWithNtt(Buffer.from('print(123)'), { fetchImpl: f.fn });
    check('sukses: hasil dari field result', out.toString() === 'OBF()');
    check('request: POST ke endpoint, JSON, body berisi source', f.calls.length === 1 && f.calls[0].url === ENDPOINT && f.calls[0].init.method === 'POST' && f.calls[0].init.headers['Content-Type'] === 'application/json');
    check('body: key sesuai snippet berisi source', JSON.parse(f.calls[0].init.body)[PAYLOAD_KEY] === 'print(123)');
  }

  // source kosong
  {
    let msg = '';
    try { await obfuscateWithNtt(Buffer.alloc(0), { fetchImpl: fakeFetch({ body: {} }).fn }); } catch (e) { msg = e.message; }
    check('source kosong: ditolak', msg === 'source kosong');
  }

  // respons error dari server, pakai data.error seperti snippet
  {
    let msg = '';
    try { await obfuscateWithNtt(Buffer.from('x'), { fetchImpl: fakeFetch({ status: 400, body: { error: 'kode tidak valid' } }).fn }); } catch (e) { msg = e.message; }
    check('HTTP error: data.error dipakai', msg === 'kode tidak valid', msg);
  }

  // HTTP error tanpa error field: fallback ke status
  {
    let msg = '';
    try { await obfuscateWithNtt(Buffer.from('x'), { fetchImpl: fakeFetch({ status: 500, body: {} }).fn }); } catch (e) { msg = e.message; }
    check('HTTP error tanpa error: pesan memuat status', msg.includes('500'), msg);
  }

  // bukan JSON
  {
    let msg = '';
    try { await obfuscateWithNtt(Buffer.from('x'), { fetchImpl: fakeFetch({ status: 204, bad: true }).fn }); } catch (e) { msg = e.message; }
    check('bukan JSON: pesan jelas dengan status', msg.includes('bukan JSON') && msg.includes('204'), msg);
  }

  // result tidak ada
  {
    let msg = '';
    try { await obfuscateWithNtt(Buffer.from('x'), { fetchImpl: fakeFetch({ body: { ok: true } }).fn }); } catch (e) { msg = e.message; }
    check('tanpa result: ditolak', msg.includes('result tidak ada'), msg);
  }

  // hasil sama dengan source
  {
    const src = 'print("hi")';
    let msg = '';
    try { await obfuscateWithNtt(Buffer.from(src), { fetchImpl: fakeFetch({ body: { result: src } }).fn }); } catch (e) { msg = e.message; }
    check('hasil sama dengan source: ditolak', msg.includes('tanpa perubahan'), msg);
  }

  // antrean: nilai diteruskan apa adanya
  {
    const f = fakeFetch({ body: { queue: 3 } });
    const q = await getNttQueue({ fetchImpl: f.fn });
    check('queue: GET ke endpoint queue, nilai dikembalikan', q === 3 && f.calls[0].url === QUEUE_ENDPOINT && f.calls[0].init.method === undefined);
  }

  // antrean gagal: tidak melempar, hasil null
  {
    const q = await getNttQueue({ fetchImpl: async () => { throw new Error('mati'); } });
    check('queue: gagal jaringan -> null, tidak melempar', q === null);
  }

  // antrean bukan JSON: null
  {
    const q = await getNttQueue({ fetchImpl: fakeFetch({ bad: true }).fn });
    check('queue: bukan JSON -> null', q === null);
  }

  // field queue tidak ada: null
  {
    const q = await getNttQueue({ fetchImpl: fakeFetch({ body: {} }).fn });
    check('queue: field tidak ada -> null', q === null);
  }

  console.log({ ok, fail });
  process.exit(fail ? 1 : 0);
})();
